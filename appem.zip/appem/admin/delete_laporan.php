<?php
require '../koneksi.php';
$id_pengaduan=$_GET['id_pengaduan'];

$sql=mysqli_query($conn, "DELETE FROM pengaduan where id_pengaduan='$id_pengaduan' ");

if ($sql)
{
    ?>
    <script type="text/javascript">
    alert ('Data Berhasil Dihapus');
    window.location='admin.php?url=lihat_laporan';
    </script>
<?php
}
?>